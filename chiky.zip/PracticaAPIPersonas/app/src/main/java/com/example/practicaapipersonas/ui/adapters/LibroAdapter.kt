package com.example.practicaapipersonas.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import android.widget.TextView
import com.example.practicaapipersonas.R
import com.example.practicaapipersonas.models.Libro

class LibroAdapter(var libros: MutableList<Libro>) : RecyclerView.Adapter<LibroAdapter.LibroViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LibroViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.libro_item, parent, false)
        return LibroViewHolder(view)
    }

    override fun onBindViewHolder(holder: LibroViewHolder, position: Int) {
        val libro = libros[position]
        holder.bind(libro)
    }

    override fun getItemCount() = libros.size

    class LibroViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val nombreTextView: TextView = itemView.findViewById(R.id.nombreTextView)
        private val autorTextView: TextView = itemView.findViewById(R.id.autorTextView)

        fun bind(libro: Libro) {
            nombreTextView.text = libro.nombre
            autorTextView.text = libro.autor
        }
    }

    interface OnLibroClickListener {
        fun onLibroClick(libro: Libro)
    }

    fun updateLibros(newLibros: List<Libro>) {
        libros.clear()
        libros.addAll(newLibros)
        notifyDataSetChanged()
    }
}