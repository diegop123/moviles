package com.example.practicaapipersonas.models

data class LibroGenero(
    val libro_id: Int,
    val genero_id: Int
)