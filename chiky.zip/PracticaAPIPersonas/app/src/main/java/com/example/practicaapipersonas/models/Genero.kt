package com.example.practicaapipersonas.models


data class Genero(
    val nombre: String
)